// Fill this in with your own Firebase project's config.
// Get it from: Firebase Console → Project Settings → General → "Your apps" → SDK setup and configuration.
// Both index.html and leaderboard.html read this file, so you only need to paste your keys once.
window.INKWELL_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBR_FNZkTu5Y5-uwgZofBlX-nWLG8WjrTc",
  authDomain: "typefastoro.firebaseapp.com",
  projectId: "typefastoro",
  storageBucket: "typefastoro.firebasestorage.app",
  messagingSenderId: "409654650918",
  appId: "1:409654650918:web:7822f7e2d10d0ce35f9ee7"
};
