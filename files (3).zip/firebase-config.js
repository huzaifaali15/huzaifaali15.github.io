// Fill this in with your own Firebase project's config.
// Get it from: Firebase Console → Project Settings → General → "Your apps" → SDK setup and configuration.
// Both index.html and leaderboard.html read this file, so you only need to paste your keys once.
window.INKWELL_FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
